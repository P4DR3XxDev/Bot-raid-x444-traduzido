# x444-Nuker
x444, fastest nuker on discord written in py.
## Installation
For compiled version:

- Download latest version from [releases](https://github.com/notspeezy/x444-Nuker/releases)
- Extract all the content
- Run x444.exe

For python version:

- Install required modules from "requirements.txt"
- Provide your bot token and channel/roles/messages content in config.json file
- Provide your proxies (optional)
- Run x444.py
## Todo
- [x] Proxy supported HTTP/s [ip:port][user:pass@ip:port] formats
- [ ] Nuke command (all together)
- [ ] Change Guild Name
- [ ] Change Guild Icon
- [ ] Change Vanity
- [ ] Nickname All
- [x] Ban all members
- [x] Kick all members
- [x] Prune members
- [x] Create Channels
- [x] Create Roles
- [ ] Create Emojis
- [ ] Create Stickers
- [x] Delete Channels
- [x] Delete Roles
- [x] Delete Emojis
- [ ] Delete Stickers
- [x] Spam Channels
- [x] Pick a random channel/role name and message from config.json file
## Contact
- Discord: sp#5084
- Server: discord.gg/hcaptcha
- Telegram: @notspeezy
## Preview
![banall](https://user-images.githubusercontent.com/93849730/180956781-eb23c827-c3ec-4e80-a880-da98ece0bd1e.gif)
![avgbans](https://i.postimg.cc/T2NhVPbb/banspersec.png)
## Skids
- [Nice2Basic](https://github.com/Nice2Basic) (https://youtu.be/UzaSIoUQ-Xs)
- [140hermione](https://github.com/140hermione) (https://youtu.be/9eYxI2F3gQQ)
- [AxZeRxD](https://github.com/AxZeRxD) (https://github.com/AxZeRxD/Thallium-Nuker)
